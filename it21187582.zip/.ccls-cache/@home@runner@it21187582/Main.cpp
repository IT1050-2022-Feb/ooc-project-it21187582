#include <iostream> 
#include "Report.h" 
#include "Feedback.h"
using namespace std;
int main()
{ 
Report rpNo;
rpNo.Reports(4197392, (char*)"CUSTOMR REPORTS"); rpNo.displayReport();
cout<< "\n" << endl;
cout<< "--------------------------------" << endl;

  {
Feedback fb;
fb.feedback(17, (char*)"Saman Perera", (char*)"samanPerera@gmail.com", (char*)"Great Solution"); 
fb.displayFeedback(); 
    cout << "\n" << endl;
    }

return 0; 
}